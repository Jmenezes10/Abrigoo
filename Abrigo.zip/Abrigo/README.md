# Abrigo

App parecido com o Shelter: cria um perfil isolado (perfil de trabalho do Android),
clona apps para dentro dele e permite congelar/descongelar esses apps.

Requer Android 9 ou mais novo. Não precisa de root.

## Gerar o APK (grátis, pelo GitHub)

1. Crie uma conta em github.com e um repositório novo e vazio chamado `abrigo`.
2. Crie um token em github.com › Settings › Developer settings › Personal access tokens ›
   Tokens (classic) › Generate new token, marcando `repo` e `workflow`. Copie o token.
3. No Termux, com o zip baixado na pasta Download:

```bash
pkg install -y git unzip
termux-setup-storage
cd ~ && unzip ~/storage/downloads/Abrigo.zip && cd Abrigo
git init && git add . && git commit -m "Abrigo 1.0"
git branch -M main
git remote add origin https://SEU_USUARIO:SEU_TOKEN@github.com/SEU_USUARIO/abrigo.git
git push -u origin main
```

4. No GitHub, abra a aba **Actions** do repositório. Espere a compilação "Gerar APK"
   ficar verde (uns 3–5 minutos), toque nela e baixe **Abrigo-apk** em *Artifacts*.
5. Extraia o zip baixado e instale o `app-debug.apk`.

## Como usar

1. Abra o Abrigo e toque em **Criar perfil isolado**. Siga as telas do Android.
2. Na gaveta de apps aparecerá uma aba **Trabalho** com o Abrigo (ícone com maletinha).
   Esse é o painel do perfil isolado.
3. No painel, toque num app para **clonar**, **abrir**, **congelar** ou **remover**.
4. O ícone **Congelar tudo** (floco de neve, no perfil isolado) congela todos os apps de uma vez.
   O mesmo botão existe na tela inicial do Abrigo.

Para apagar tudo: Configurações › Contas › Remover perfil de trabalho.

## Limitações

- Só pode existir um perfil de trabalho. Se já tiver Shelter, Island ou um da empresa, remova antes.
- Alguns aparelhos (ex.: MIUI antigos) bloqueiam a criação do perfil.
- Para clonar, o app precisa estar instalado no perfil principal primeiro.
