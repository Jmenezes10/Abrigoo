package br.com.abrigo;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/** Recebe o aviso de que o perfil isolado foi criado. */
public class AdminReceiver extends DeviceAdminReceiver {
    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        Abrigo.finishSetup(context);
    }
}
