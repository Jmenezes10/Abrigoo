package br.com.abrigo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Aberta pelo Android logo depois que o perfil isolado é criado. */
public class ProvisioningSuccessActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Abrigo.finishSetup(this);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}
