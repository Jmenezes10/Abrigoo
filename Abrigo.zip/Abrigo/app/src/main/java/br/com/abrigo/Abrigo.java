package br.com.abrigo;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Funções compartilhadas: detectar o perfil isolado, listar, clonar e congelar apps. */
public final class Abrigo {

    private Abrigo() {}

    /** Um app do aparelho e o estado dele dentro do perfil isolado. */
    public static final class AppItem {
        public String pkg;
        public String label;
        public Drawable icon;
        public boolean system;
        public boolean installed; // existe dentro do perfil isolado
        public boolean frozen;    // está congelado (escondido) no perfil isolado
    }

    public static ComponentName admin(Context c) {
        return new ComponentName(c, AdminReceiver.class);
    }

    public static DevicePolicyManager dpm(Context c) {
        return c.getSystemService(DevicePolicyManager.class);
    }

    /** true quando esta cópia do app está rodando DENTRO do perfil isolado. */
    public static boolean isWork(Context c) {
        return dpm(c).isProfileOwnerApp(c.getPackageName());
    }

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("abrigo", Context.MODE_PRIVATE);
    }

    /** Termina de configurar o perfil isolado. Pode ser chamada várias vezes. */
    public static void finishSetup(Context c) {
        if (!isWork(c)) return;
        DevicePolicyManager dpm = dpm(c);
        ComponentName admin = admin(c);

        // Liga o ícone "Congelar tudo" só dentro do perfil isolado
        c.getPackageManager().setComponentEnabledSetting(
                new ComponentName(c, FreezeAllActivity.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP);

        SharedPreferences p = prefs(c);
        if (p.getBoolean("setup_done", false)) return;
        try {
            dpm.setProfileName(admin, c.getString(R.string.profile_name));
        } catch (Exception ignored) {
        }
        try {
            dpm.setProfileEnabled(admin);
        } catch (Exception ignored) {
        }
        p.edit().putBoolean("setup_done", true).apply();
    }

    /** Lista os apps do aparelho, marcando quais já estão no perfil isolado. Chamar fora da thread principal. */
    public static List<AppItem> listApps(Context c) {
        PackageManager pm = c.getPackageManager();
        DevicePolicyManager dpm = dpm(c);
        ComponentName admin = admin(c);
        List<ApplicationInfo> infos = pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES);
        List<AppItem> out = new ArrayList<>();
        for (ApplicationInfo ai : infos) {
            if (ai.packageName.equals(c.getPackageName())) continue;
            AppItem it = new AppItem();
            it.pkg = ai.packageName;
            it.system = (ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
            it.installed = (ai.flags & ApplicationInfo.FLAG_INSTALLED) != 0;
            boolean hidden = false;
            try {
                hidden = dpm.isApplicationHidden(admin, ai.packageName);
            } catch (Exception ignored) {
            }
            it.frozen = hidden;
            if (hidden) it.installed = true;
            try {
                it.label = ai.loadLabel(pm).toString();
            } catch (Exception e) {
                it.label = ai.packageName;
            }
            try {
                it.icon = ai.loadIcon(pm);
            } catch (Exception ignored) {
            }
            out.add(it);
        }
        Collections.sort(out, (a, b) -> {
            if (a.installed != b.installed) return a.installed ? -1 : 1;
            return a.label.compareToIgnoreCase(b.label);
        });
        return out;
    }

    /** Copia para o perfil isolado um app que já está instalado no perfil principal. */
    public static boolean cloneApp(Context c, AppItem it) {
        DevicePolicyManager dpm = dpm(c);
        ComponentName admin = admin(c);
        try {
            if (it.system) {
                dpm.enableSystemApp(admin, it.pkg);
                return true;
            }
            return dpm.installExistingPackage(admin, it.pkg);
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean setFrozen(Context c, String pkg, boolean frozen) {
        try {
            return dpm(c).setApplicationHidden(admin(c), pkg, frozen);
        } catch (Exception e) {
            return false;
        }
    }

    /** Congela todos os apps (não-sistema) que estão no perfil isolado. Retorna quantos. */
    public static int freezeAll(Context c) {
        if (!isWork(c)) return 0;
        PackageManager pm = c.getPackageManager();
        int n = 0;
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (ai.packageName.equals(c.getPackageName())) continue;
            if ((ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) continue;
            if (setFrozen(c, ai.packageName, true)) n++;
        }
        return n;
    }
}
