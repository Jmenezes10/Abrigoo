package br.com.abrigo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.os.UserHandle;
import android.os.UserManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Tela principal. Funciona de dois jeitos:
 *  - no perfil principal: cria o perfil isolado e abre o painel;
 *  - dentro do perfil isolado (ícone com maletinha): painel para clonar, abrir e congelar apps.
 */
public class MainActivity extends Activity {

    private static final int REQ_PROVISION = 1;

    private boolean workMode;

    // --- tela inicial (perfil principal)
    private TextView homeStatus;
    private Button homePrimary;
    private Button homeFreeze;

    // --- painel (perfil isolado)
    private final List<Abrigo.AppItem> allApps = new ArrayList<>();
    private final List<Abrigo.AppItem> shown = new ArrayList<>();
    private AppAdapter adapter;
    private EditText search;
    private CheckBox showSystem;
    private ProgressBar loading;
    private volatile boolean loadingNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        workMode = Abrigo.isWork(this);
        if (workMode) {
            Abrigo.finishSetup(this);
            buildPanel();
        } else {
            buildHome();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (workMode) loadApps();
        else refreshHome();
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // =====================================================================
    // TELA INICIAL — perfil principal
    // =====================================================================

    private void buildHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("Abrigo");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Isole e congele apps num perfil separado do Android. "
                + "Apps dentro do Abrigo não veem seus contatos, fotos e arquivos do perfil principal, "
                + "e congelados não rodam em segundo plano.");
        desc.setTextSize(15);
        desc.setPadding(0, dp(8), 0, dp(20));
        root.addView(desc);

        homeStatus = new TextView(this);
        homeStatus.setTextSize(16);
        homeStatus.setPadding(0, 0, 0, dp(16));
        root.addView(homeStatus);

        homePrimary = new Button(this);
        root.addView(homePrimary, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        homeFreeze = new Button(this);
        homeFreeze.setText("❄  Congelar tudo agora");
        root.addView(homeFreeze, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("Dica: os apps do Abrigo aparecem na gaveta de apps com uma maletinha (aba \"Trabalho\"). "
                + "Para apagar tudo, vá em Configurações › Contas › Remover perfil de trabalho.");
        hint.setTextSize(13);
        hint.setAlpha(0.7f);
        hint.setPadding(0, dp(24), 0, 0);
        root.addView(hint);

        setContentView(root);
    }

    /** Perfil isolado criado pelo Abrigo, ou null. */
    private UserHandle findOurProfile() {
        UserManager um = getSystemService(UserManager.class);
        LauncherApps la = getSystemService(LauncherApps.class);
        boolean created = Abrigo.prefs(this).getBoolean("provisioned", false);
        for (UserHandle u : um.getUserProfiles()) {
            if (u.equals(Process.myUserHandle())) continue;
            List<LauncherActivityInfo> list = la.getActivityList(getPackageName(), u);
            if ((list != null && !list.isEmpty()) || created) return u;
        }
        return null;
    }

    private boolean hasOtherProfile() {
        UserManager um = getSystemService(UserManager.class);
        for (UserHandle u : um.getUserProfiles()) {
            if (!u.equals(Process.myUserHandle())) return true;
        }
        return false;
    }

    private void refreshHome() {
        UserHandle ours = findOurProfile();
        if (ours != null) {
            homeStatus.setText("✅ Perfil isolado ativo");
            homePrimary.setEnabled(true);
            homePrimary.setText("Abrir painel do Abrigo");
            homePrimary.setOnClickListener(v -> openInProfile(ours, MainActivity.class));
            homeFreeze.setVisibility(View.VISIBLE);
            homeFreeze.setOnClickListener(v -> openInProfile(ours, FreezeAllActivity.class));
        } else if (hasOtherProfile()) {
            homeStatus.setText("⚠️ Já existe um perfil de trabalho de outro app (Shelter, Island, da empresa…). "
                    + "O Android só permite um. Remova o outro em Configurações › Contas e volte aqui.");
            homePrimary.setEnabled(false);
            homePrimary.setText("Criar perfil isolado");
            homeFreeze.setVisibility(View.GONE);
        } else {
            homeStatus.setText("Nenhum perfil isolado ainda.");
            homePrimary.setEnabled(true);
            homePrimary.setText("Criar perfil isolado");
            homePrimary.setOnClickListener(v -> startProvisioning());
            homeFreeze.setVisibility(View.GONE);
        }
    }

    private void openInProfile(UserHandle user, Class<?> cls) {
        LauncherApps la = getSystemService(LauncherApps.class);
        try {
            la.startMainActivity(new ComponentName(this, cls), user, null, null);
        } catch (Exception e) {
            toast("Não consegui abrir. Se os apps de trabalho estiverem pausados, ative-os na barra de notificações e tente de novo.");
        }
    }

    private void startProvisioning() {
        DevicePolicyManager dpm = Abrigo.dpm(this);
        if (!dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Não disponível")
                    .setMessage("Este aparelho não permite criar um perfil de trabalho agora. "
                            + "Alguns celulares (Xiaomi/MIUI antigos, por exemplo) bloqueiam esse recurso, "
                            + "ou já existe outro perfil/usuário.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        Intent i = new Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE);
        i.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, Abrigo.admin(this));
        i.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, true);
        try {
            startActivityForResult(i, REQ_PROVISION);
        } catch (ActivityNotFoundException e) {
            toast("Seu Android não tem suporte a perfil de trabalho.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PROVISION) return;
        if (resultCode == RESULT_OK) {
            Abrigo.prefs(this).edit().putBoolean("provisioned", true).apply();
            toast("Perfil isolado criado! Procure os apps com a maletinha.");
        } else {
            toast("Criação do perfil cancelada.");
        }
        refreshHome();
    }

    // =====================================================================
    // PAINEL — dentro do perfil isolado
    // =====================================================================

    private void buildPanel() {
        setTitle("Abrigo · perfil isolado");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(16), dp(12), dp(16), dp(4));

        search = new EditText(this);
        search.setHint("Buscar app");
        search.setSingleLine(true);
        top.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        showSystem = new CheckBox(this);
        showSystem.setText("Apps do sistema");
        row.addView(showSystem, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button freezeAll = new Button(this);
        freezeAll.setText("❄ Congelar todos");
        freezeAll.setOnClickListener(v -> {
            int n = Abrigo.freezeAll(this);
            toast(n == 0 ? "Nada para congelar" : n + " app(s) congelado(s)");
            loadApps();
        });
        row.addView(freezeAll);
        top.addView(row);

        TextView info = new TextView(this);
        info.setText("Toque num app para clonar, abrir, congelar ou remover.");
        info.setTextSize(13);
        info.setAlpha(0.7f);
        top.addView(info);

        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setIndeterminate(true);
        top.addView(loading);

        root.addView(top);

        ListView list = new ListView(this);
        adapter = new AppAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> showActions(shown.get(pos)));
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { applyFilter(); }
        });
        showSystem.setOnCheckedChangeListener((b, checked) -> applyFilter());

        setContentView(root);
    }

    private void loadApps() {
        if (loadingNow) return;
        loadingNow = true;
        loading.setVisibility(View.VISIBLE);
        new Thread(() -> {
            List<Abrigo.AppItem> items = Abrigo.listApps(getApplicationContext());
            runOnUiThread(() -> {
                loadingNow = false;
                loading.setVisibility(View.GONE);
                allApps.clear();
                allApps.addAll(items);
                applyFilter();
            });
        }).start();
    }

    private void applyFilter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean sys = showSystem.isChecked();
        shown.clear();
        for (Abrigo.AppItem it : allApps) {
            // apps do sistema só aparecem quando "Apps do sistema" está marcado
            if (it.system && !sys) continue;
            if (!q.isEmpty() && !it.label.toLowerCase(Locale.ROOT).contains(q)
                    && !it.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(it);
        }
        adapter.notifyDataSetChanged();
    }

    private void showActions(Abrigo.AppItem it) {
        List<String> labels = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();

        if (!it.installed) {
            labels.add("📥 Clonar para o Abrigo");
            actions.add(() -> {
                boolean ok = Abrigo.cloneApp(this, it);
                toast(ok ? "Clonado! O app agora aparece com a maletinha." : "Não foi possível clonar este app.");
                loadApps();
            });
        } else if (it.frozen) {
            labels.add("▶️ Descongelar e abrir");
            actions.add(() -> {
                Abrigo.setFrozen(this, it.pkg, false);
                openApp(it);
                loadApps();
            });
            labels.add("🔥 Descongelar");
            actions.add(() -> {
                toast(Abrigo.setFrozen(this, it.pkg, false) ? "Descongelado" : "Falhou");
                loadApps();
            });
            labels.add("🗑 Remover do Abrigo");
            actions.add(() -> {
                Abrigo.setFrozen(this, it.pkg, false);
                uninstall(it);
            });
        } else {
            labels.add("▶️ Abrir");
            actions.add(() -> openApp(it));
            labels.add("❄️ Congelar");
            actions.add(() -> {
                toast(Abrigo.setFrozen(this, it.pkg, true) ? "Congelado" : "Este app não pode ser congelado");
                loadApps();
            });
            labels.add("🗑 Remover do Abrigo");
            actions.add(() -> uninstall(it));
        }

        new AlertDialog.Builder(this)
                .setTitle(it.label)
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openApp(Abrigo.AppItem it) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(it.pkg);
        if (launch == null) {
            toast("Este app não tem tela para abrir.");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(launch);
        } catch (Exception e) {
            toast("Não consegui abrir este app.");
        }
    }

    private void uninstall(Abrigo.AppItem it) {
        // Remove só a cópia do perfil isolado; o app continua no perfil principal
        Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + it.pkg));
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Não consegui remover.");
        }
    }

    // --- lista de apps -----------------------------------------------------

    private static final class Holder {
        ImageView icon;
        TextView name;
        TextView status;
    }

    private final class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(16), dp(10), dp(16), dp(10));

                h = new Holder();
                h.icon = new ImageView(MainActivity.this);
                row.addView(h.icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

                LinearLayout texts = new LinearLayout(MainActivity.this);
                texts.setOrientation(LinearLayout.VERTICAL);
                texts.setPadding(dp(14), 0, 0, 0);
                h.name = new TextView(MainActivity.this);
                h.name.setTextSize(16);
                h.name.setSingleLine(true);
                h.status = new TextView(MainActivity.this);
                h.status.setTextSize(13);
                texts.addView(h.name);
                texts.addView(h.status);
                row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

                row.setTag(h);
                convertView = row;
            } else {
                h = (Holder) convertView.getTag();
            }

            Abrigo.AppItem it = shown.get(position);
            h.icon.setImageDrawable(it.icon);
            h.name.setText(it.label);
            if (!it.installed) {
                h.status.setText("Fora do Abrigo");
                h.status.setTextColor(0xFF888888);
                h.icon.setAlpha(0.45f);
            } else if (it.frozen) {
                h.status.setText("No Abrigo · ❄ congelado");
                h.status.setTextColor(0xFF2B7BB9);
                h.icon.setAlpha(0.6f);
            } else {
                h.status.setText("No Abrigo · ativo");
                h.status.setTextColor(0xFF3FA37C);
                h.icon.setAlpha(1f);
            }
            return convertView;
        }
    }
}
