package br.com.abrigo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

/** Atalho de um toque: congela todos os apps do perfil isolado e fecha. */
public class FreezeAllActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int n = Abrigo.freezeAll(this);
        Toast.makeText(this, n == 0 ? "Nada para congelar" : n + " app(s) congelado(s)", Toast.LENGTH_SHORT).show();
        finish();
    }
}
